rm [
rm [[
rm ar
rm arp
rm arping
rm ash
rm awk
rm basename
rm blkid
rm brctl
rm bunzip2
rm bzcat
rm bzip2
rm cal
rm catv
rm chat
rm chattr
rm chgrp
rm chmod
rm chown
rm chroot
rm cksum
rm clear
rm comm
rm cmp
rm cp
rm cpio
rm cttyhack
rm cut
rm date
rm dc
rm df
rm dd
rm depmod
rm devmem
rm diff
rm dirname
rm dmesg
rm dnsd
rm dnsdomainname
rm dos2unix
rm du
rm echo
rm ed
rm egrep
rm env
rm expand
rm expr
rm false
rm fdisk
rm fgrep
rm find
rm fold
rm free
rm freeramdisk
rm fsck
rm ftpget
rm ftpput
rm fuser
rm getopt
rm grep
rm gunzip
rm gzip
rm hd
rm head
rm hexdump
rm hostid
rm hostname
rm id
rm ifconfig
rm insmod
rm ip
rm inetd
rm install
rm last
rm length
rm less
rm logname
rm losetup
rm ls
rm lspci
rm lsusb
rm lsattr
rm lzmacat
rm lzopcat
rm md5sum
rm mesg
rm microcom
rm mkfifo
rm mknod
rm mkswap
rm mktemp
rm modprobe
rm more
rm mount
rm mountpoint
rm mv
rm nc
rm netstat
rm nice
rm nmeter
rm nohup
rm nslookup
rm od
rm patch
rm pgrep
rm pidof
rm ping
rm pkill
rm printf
rm ps
rm pscan
rm pwd
rm rdev
rm readlink
rm realpath
rm reboot
rm renice
rm reset
rm rm
rm rmdir
rm rmmod
rm route
rm run-parts
rm rx
rm script
rm sed
rm seq
rm setsid
rm sh
rm sha1sum
rm sha256sum
rm sort
rm split
rm stat
rm strings
rm stty
rm sum
rm sysctl
rm tac
rm tail
rm tar
rm tee
rm telnet
rm telnetd
rm test
rm tftp
rm tftpd
rm time
rm top
rm touch
rm tr
rm traceroute
rm true
rm tty
rm ttysize
rm umount
rm uname
rm uncompress
rm unexpand
rm uniq
rm unix2dos
rm unlzop
rm unzip
rm uptime
rm usleep
rm uudecode
rm uuencode
rm vi
rm watch
rm wc
rm wget
rm which
rm whoami
rm xargs
rm yes
rm zcat
ln -s busybox.exe [
ln -s busybox.exe [[
ln -s busybox.exe arp
ln -s busybox.exe ash
ln -s busybox.exe awk
ln -s busybox.exe basename
ln -s busybox.exe bbconfig
ln -s busybox.exe brctl
ln -s busybox.exe bunzip2
ln -s busybox.exe bzcat
ln -s busybox.exe bzip2
ln -s busybox.exe cal
ln -s busybox.exe cat
ln -s busybox.exe catv
ln -s busybox.exe chgrp
ln -s busybox.exe chmod
ln -s busybox.exe chown
ln -s busybox.exe chroot
ln -s busybox.exe chvt
ln -s busybox.exe cksum
ln -s busybox.exe clear
ln -s busybox.exe cmp
ln -s busybox.exe cp
ln -s busybox.exe cpio
ln -s busybox.exe cut
ln -s busybox.exe date
ln -s busybox.exe dc
ln -s busybox.exe dd
ln -s busybox.exe deallocvt
ln -s busybox.exe depmod
ln -s busybox.exe devmem
ln -s busybox.exe df
ln -s busybox.exe diff
ln -s busybox.exe dirname
ln -s busybox.exe dmesg
ln -s busybox.exe dnsd
ln -s busybox.exe dos2unix
ln -s busybox.exe du
ln -s busybox.exe echo
ln -s busybox.exe ed
ln -s busybox.exe egrep
ln -s busybox.exe env
ln -s busybox.exe expr
ln -s busybox.exe false
ln -s busybox.exe fdisk
ln -s busybox.exe fgrep
ln -s busybox.exe find
ln -s busybox.exe fold
ln -s busybox.exe free
ln -s busybox.exe freeramdisk
ln -s busybox.exe fuser
ln -s busybox.exe ftpget
ln -s busybox.exe ftpput
ln -s busybox.exe getopt
ln -s busybox.exe grep
ln -s busybox.exe gunzip
ln -s busybox.exe gzip
ln -s busybox.exe halt
ln -s busybox.exe head
ln -s busybox.exe hexdump
ln -s busybox.exe id
ln -s busybox.exe ifconfig
ln -s busybox.exe insmod
ln -s busybox.exe install
ln -s busybox.exe ip
ln -s busybox.exe kill
ln -s busybox.exe killall
ln -s busybox.exe killall5
ln -s busybox.exe length
ln -s busybox.exe less
ln -s busybox.exe ln
ln -s busybox.exe losetup
ln -s busybox.exe ls
ln -s busybox.exe lsmod
ln -s busybox.exe lspci
ln -s busybox.exe lsusb
ln -s busybox.exe lzmacat
ln -s busybox.exe lzop
ln -s busybox.exe lzopcat
ln -s busybox.exe man
ln -s busybox.exe md5sum
#ln -s busybox.exe mkdir
ln -s busybox.exe mke2fs
ln -s busybox.exe mkfifo
ln -s busybox.exe mkfs.ext2
ln -s busybox.exe mknod
ln -s busybox.exe mkswap
ln -s busybox.exe mktemp
ln -s busybox.exe modprobe
ln -s busybox.exe more
ln -s busybox.exe mount
ln -s busybox.exe mountpoint
ln -s busybox.exe mv
ln -s busybox.exe nc
ln -s busybox.exe netstat
ln -s busybox.exe nice
ln -s busybox.exe nmeter
ln -s busybox.exe nohup
ln -s busybox.exe nslookup
ln -s busybox.exe ntpd
ln -s busybox.exe od
ln -s busybox.exe openvt
ln -s busybox.exe patch
ln -s busybox.exe pgrep
ln -s busybox.exe pidof
#ln -s busybox.exe ping
ln -s busybox.exe pkill
ln -s busybox.exe poweroff
ln -s busybox.exe printenv
ln -s busybox.exe printf
ln -s busybox.exe ps
#ln -s busybox.exe pwd
ln -s busybox.exe pscan
ln -s busybox.exe rdev
ln -s busybox.exe readlink
ln -s busybox.exe realpath
ln -s busybox.exe renice
ln -s busybox.exe renice
ln -s busybox.exe reset
ln -s busybox.exe rm
ln -s busybox.exe rmdir
ln -s busybox.exe rmmod
ln -s busybox.exe route
ln -s busybox.exe run-parts
ln -s busybox.exe sed
ln -s busybox.exe seq
ln -s busybox.exe setsid
ln -s busybox.exe sh
ln -s busybox.exe sha1sum
ln -s busybox.exe sha256sum
ln -s busybox.exe sha512sum
ln -s busybox.exe sleep
ln -s busybox.exe sort
ln -s busybox.exe split
ln -s busybox.exe stat
ln -s busybox.exe strings
ln -s busybox.exe stty
ln -s busybox.exe swapoff
ln -s busybox.exe swapon
ln -s busybox.exe switch_root
ln -s busybox.exe sync
ln -s busybox.exe sysctl
ln -s busybox.exe tac
ln -s busybox.exe tail
ln -s busybox.exe tar
ln -s busybox.exe tee
ln -s busybox.exe telnet
ln -s busybox.exe test
ln -s busybox.exe tftp
ln -s busybox.exe time
ln -s busybox.exe top
ln -s busybox.exe touch
ln -s busybox.exe tr
ln -s busybox.exe traceroute
ln -s busybox.exe true
ln -s busybox.exe tty
ln -s busybox.exe umount
ln -s busybox.exe uname
ln -s busybox.exe uniq
ln -s busybox.exe unix2dos
ln -s busybox.exe unlzma
ln -s busybox.exe unlzop
ln -s busybox.exe unzip
ln -s busybox.exe uptime
ln -s busybox.exe usleep
ln -s busybox.exe uudecode
ln -s busybox.exe uuencode
ln -s busybox.exe vi
ln -s busybox.exe watch
ln -s busybox.exe wc
ln -s busybox.exe wget
ln -s busybox.exe which
ln -s busybox.exe whoami
ln -s busybox.exe xargs
ln -s busybox.exe yes
ln -s busybox.exe zcat

chmod 755 busybox.exe
chmod 755 sftp-server
chmod 755 ssh
chmod 755 scp
chmod 755 dropbear
chmod 755 dropbearkey
chmod 755 bash
chmod 755 wy60
chmod 755 ether-wake
chmod 755 frotz
chmod 755 ftp
chmod 755 openssh
chmod 755 ssh-add
chmod 755 ssh-keyscan
chmod 755 ssh-agent
chmod 755 ssh-keysign
chmod 755 openscp
chmod 755 ssh-keygen
