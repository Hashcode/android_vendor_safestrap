#!/sbin/busybox sh
cd /dev/block
/sbin/busybox rm system
/sbin/busybox rm preinstall
/sbin/busybox ln -s /dev/block/mmcblk1p22 system
/sbin/busybox ln -s /dev/block/mmcblk1p20 systemorig
/sbin/taskset -p -c 0,1 1
