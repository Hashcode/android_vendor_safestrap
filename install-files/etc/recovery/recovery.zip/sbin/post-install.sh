#!/sbin/sh

# This script is run post zip install to find hijacks and clear them up, as well as fix up flashes w/o /system/etc/rootfs folders

# mount /system
if [ ! -d "/system/bin" ]; then
  mount -t ext3 /dev/block/system /system
fi

# look for "logwrapper.bin"
if [ -f "/system/bin/logwrapper.bin" ]; then
  rm /system/bin/logwrapper
  mv /system/bin/logwrapper.bin /system/bin/logwrapper
fi

# make sure we have a /system/etc/rootfs folder
if [ ! -d "/system/etc/rootfs" ]; then
  mkdir -p /system/etc/rootfs
  cp /etc/rootfs/* /system/etc/rootfs
  chmod 644 /system/etc/rootfs/*
  chmod 755 /system/etc/rootfs/*.rc
fi

umount /system
