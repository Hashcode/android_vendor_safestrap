#!/sbin/busybox sh
cd /dev/block
/sbin/busybox rm system
/sbin/busybox rm webtop
/sbin/busybox ln -s /dev/block/mmcblk1p23 system
/sbin/busybox ln -s /dev/block/mmcblk1p20 systemorig
/sbin/taskset -p -c 0,1 1
