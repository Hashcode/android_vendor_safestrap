#!/sbin/busybox sh
cd /dev/block
/sbin/busybox rm system
/sbin/busybox rm preinstall
/sbin/busybox ln -s /dev/block/mmcblk1p23 system
/sbin/busybox ln -s /dev/block/mmcblk1p21 systemorig
#/sbin/busybox ln -s /dev/block/mmcblk0p2 system
#/sbin/busybox ln -s /dev/block/mmcblk1p21 systemorig
#/sbin/busybox rm userdata
#/sbin/busybox ln -s /dev/block/mmcblk0p3 userdata
#/sbin/busybox ln -s /dev/block/mmcblk1p24 userdataorig

