#!/sbin/busybox sh
cd /dev/block
/sbin/busybox rm system
/sbin/busybox rm webtop
/sbin/busybox ln -s /dev/block/mmcblk1p24 system
/sbin/busybox ln -s /dev/block/mmcblk1p21 systemorig
/sbin/taskset -p -c 0,1 1
